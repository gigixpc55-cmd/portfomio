# Pino Portfolio Website

A responsive, single-page creative portfolio for Pino. Built with HTML, CSS, and vanilla JavaScript.

## Before publishing
1. Open `index.html` in a code editor.
2. Search for `213000000000` and replace it with your WhatsApp number, country code included, digits only (no `+`, spaces, or dashes). Example format: `213555123456`.
3. Replace the six illustrative project cards with your own real projects and update the copy.
4. Optional: update the page title, description, and social links.

## Preview locally
Open `index.html` in a browser.

## Publish for free with Netlify Drop
1. Extract `pino-portfolio.zip`.
2. Visit https://app.netlify.com/drop
3. Drag the extracted `pino_portfolio` folder (the folder containing `index.html`) onto the page.
4. Netlify will publish it and give you a public URL. You can later connect a custom domain in the Netlify dashboard.

Alternative: GitHub Pages can host the site from a GitHub repository.

## Notes
- The site is responsive for desktop and mobile.
- Project artwork is made from CSS shapes and is illustrative; replace it with real thumbnails or video embeds for your final portfolio.
- Google Fonts are loaded online; system fallback fonts are included.
